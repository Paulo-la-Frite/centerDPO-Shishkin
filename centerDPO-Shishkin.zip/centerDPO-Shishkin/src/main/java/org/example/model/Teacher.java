package org.example.model;

import java.time.LocalDate;

public class Teacher extends Person {

    private int teacherId;
    private String specialization;
    private int experienceYears;
    private double salary;

    public Teacher(int id,
                   String lastName,
                   String firstName,
                   String middleName,
                   LocalDate birthDate,
                   String gender,
                   String phone,
                   String email,
                   int teacherId,
                   String specialization,
                   int experienceYears,
                   double salary) {

        super(id, lastName, firstName, middleName,
                birthDate, gender, phone, email);

        this.teacherId = teacherId;
        this.specialization = specialization;
        this.experienceYears = experienceYears;
        this.salary = salary;
    }

    public int getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public int getExperienceYears() {
        return experienceYears;
    }

    public void setExperienceYears(int experienceYears) {
        this.experienceYears = experienceYears;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Преподаватель: " + getFullName() +
                ", Специализация: " + specialization +
                ", Стаж: " + experienceYears;
    }
}