package org.example.model;

public class Course {

    private int courseId;
    private String courseName;
    private int hours;
    private int teacherId;
    private int programId;

    public Course(int courseId,
                  String courseName,
                  int hours,
                  int teacherId,
                  int programId) {

        this.courseId = courseId;
        this.courseName = courseName;
        this.hours = hours;
        this.teacherId = teacherId;
        this.programId = programId;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getHours() {
        return hours;
    }

    public void setHours(int hours) {
        this.hours = hours;
    }

    public int getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }

    public int getProgramId() {
        return programId;
    }

    public void setProgramId(int programId) {
        this.programId = programId;
    }

    @Override
    public String toString() {
        return "Курс: " + courseName +
                ", Часы: " + hours;
    }
}