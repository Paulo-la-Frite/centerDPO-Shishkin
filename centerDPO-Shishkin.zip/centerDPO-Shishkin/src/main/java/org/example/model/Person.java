package org.example.model;

import java.time.LocalDate;
import java.time.Period;

public class Person {

    protected int id;
    protected String lastName;
    protected String firstName;
    protected String middleName;
    protected LocalDate birthDate;
    protected String gender;
    protected String phone;
    protected String email;

    public Person(int id,
                  String lastName,
                  String firstName,
                  String middleName,
                  LocalDate birthDate,
                  String gender,
                  String phone,
                  String email) {

        this.id = id;
        this.lastName = lastName;
        this.firstName = firstName;
        this.middleName = middleName;
        this.birthDate = birthDate;
        this.gender = gender;
        this.phone = phone;
        this.email = email;
    }

    public String getFullName() {
        return lastName + " " + firstName + " " + middleName;
    }

    public int getAge() {
        return Period.between(birthDate, LocalDate.now()).getYears();
    }

    @Override
    public String toString() {
        return "ID: " + id +
                ", ФИО: " + getFullName() +
                ", Возраст: " + getAge() +
                ", Телефон: " + phone;
    }

    public int getId() {
        return id;
    }

    public String getLastName() {
        return lastName;
    }

    public String getFirstName() {
        return firstName;
    }
}