package org.example.model;

import java.time.LocalDate;

public class Student extends Person {

    private int studentId;
    private int programId;
    private int enrollmentYear;
    private String status;

    public Student(int id,
                   String lastName,
                   String firstName,
                   String middleName,
                   LocalDate birthDate,
                   String gender,
                   String phone,
                   String email,
                   int studentId,
                   int programId,
                   int enrollmentYear,
                   String status) {

        super(id, lastName, firstName, middleName,
                birthDate, gender, phone, email);

        this.studentId = studentId;
        this.programId = programId;
        this.enrollmentYear = enrollmentYear;
        this.status = status;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public int getProgramId() {
        return programId;
    }

    public void setProgramId(int programId) {
        this.programId = programId;
    }

    public int getEnrollmentYear() {
        return enrollmentYear;
    }

    public void setEnrollmentYear(int enrollmentYear) {
        this.enrollmentYear = enrollmentYear;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Студент: " + getFullName() +
                ", ID студента: " + studentId +
                ", Год поступления: " + enrollmentYear +
                ", Статус: " + status;
    }
}