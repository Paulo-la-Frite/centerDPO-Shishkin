package org.example.service;

import org.example.model.Program;
import org.example.model.Student;
import org.example.model.Teacher;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class FileInputOutput {

    public static void saveStudents(ArrayList<Student> students) {

        try (BufferedWriter writer = new BufferedWriter(
                new FileWriter("src/main/resources/data/students.csv"))) {

            for (Student student : students) {

                writer.write(
                        student.getId() + "," +
                                student.getLastName() + "," +
                                student.getFirstName()
                );

                writer.newLine();
            }

            System.out.println("Студенты сохранены в файл");

        } catch (IOException e) {
            System.out.println("Ошибка сохранения студентов");
        }
    }

    public static ArrayList<Student> loadStudents() {

        ArrayList<Student> students = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(
                new FileReader("src/main/resources/data/students.csv"))) {

            String line;

            while ((line = reader.readLine()) != null) {

                String[] data = line.split(",");

                Student student = new Student(
                        Integer.parseInt(data[0]),
                        data[1],
                        data[2],
                        "Иванович",
                        LocalDate.of(2000, 1, 1),
                        "М",
                        "+79999999999",
                        "mail@mail.ru",
                        Integer.parseInt(data[0]),
                        1,
                        2024,
                        "Обучается"
                );

                students.add(student);
            }

            System.out.println("Студенты загружены из файла");

        } catch (IOException e) {
            System.out.println("Ошибка загрузки студентов");
        }

        return students;
    }

    public static void saveTeachers(ArrayList<Teacher> teachers) {

        try (BufferedWriter writer = new BufferedWriter(
                new FileWriter("src/main/resources/data/teachers.csv"))) {

            for (Teacher teacher : teachers) {

                writer.write(
                        teacher.getId() + "," +
                                teacher.getLastName() + "," +
                                teacher.getFirstName()
                );

                writer.newLine();
            }

            System.out.println("Преподаватели сохранены");

        } catch (IOException e) {
            System.out.println("Ошибка сохранения преподавателей");
        }
    }

    public static ArrayList<Teacher> loadTeachers() {

        ArrayList<Teacher> teachers = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(
                new FileReader("src/main/resources/data/teachers.csv"))) {

            String line;

            while ((line = reader.readLine()) != null) {

                String[] data = line.split(",");

                Teacher teacher = new Teacher(
                        Integer.parseInt(data[0]),
                        data[1],
                        data[2],
                        "Петрович",
                        LocalDate.of(1980, 1, 1),
                        "М",
                        "+78888888888",
                        "teacher@mail.ru",
                        Integer.parseInt(data[0]),
                        "Java",
                        10,
                        100000
                );

                teachers.add(teacher);
            }

            System.out.println("Преподаватели загружены");

        } catch (IOException e) {
            System.out.println("Ошибка загрузки преподавателей");
        }

        return teachers;
    }

    public static void savePrograms(ArrayList<Program> programs) {

        try (BufferedWriter writer = new BufferedWriter(
                new FileWriter("src/main/resources/data/programs.csv"))) {

            for (Program program : programs) {

                writer.write(
                        program.getProgramId() + "," +
                                program.getProgramName()
                );

                writer.newLine();
            }

            System.out.println("Программы сохранены");

        } catch (IOException e) {
            System.out.println("Ошибка сохранения программ");
        }
    }
}