package org.example;

import org.example.model.Program;
import org.example.model.Student;
import org.example.model.Teacher;
import org.example.service.FileInputOutput;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    static ArrayList<Student> students = new ArrayList<>();
    static ArrayList<Teacher> teachers = new ArrayList<>();
    static ArrayList<Program> programs = new ArrayList<>();

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        students = FileInputOutput.loadStudents();
        teachers = FileInputOutput.loadTeachers();

        boolean running = true;

        while (running) {

            printMenu();

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {

                case 1:
                    addStudent();
                    break;

                case 2:
                    addTeacher();
                    break;

                case 3:
                    addProgram();
                    break;

                case 4:
                    showAllStudents();
                    break;

                case 5:
                    showAllTeachers();
                    break;

                case 0:

                    FileInputOutput.saveStudents(students);
                    FileInputOutput.saveTeachers(teachers);
                    FileInputOutput.savePrograms(programs);

                    running = false;
                    System.out.println("Программа завершена");
                    break;

                default:
                    System.out.println("Неверный пункт меню");
            }
        }
    }

    public static void printMenu() {

        System.out.println("\n===== УЧЕБНЫЙ ЦЕНТР =====");
        System.out.println("1. Добавить студента");
        System.out.println("2. Добавить преподавателя");
        System.out.println("3. Добавить программу");
        System.out.println("4. Показать студентов");
        System.out.println("5. Показать преподавателей");
        System.out.println("0. Выход");
        System.out.print("Выберите пункт: ");
    }

    public static void addStudent() {

        System.out.println("\nДобавление студента");

        System.out.print("ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Фамилия: ");
        String lastName = scanner.nextLine();

        System.out.print("Имя: ");
        String firstName = scanner.nextLine();

        Student student = new Student(
                id,
                lastName,
                firstName,
                "Иванович",
                LocalDate.of(2000, 1, 1),
                "М",
                "+79999999999",
                "student@mail.ru",
                id,
                1,
                2024,
                "Обучается"
        );

        students.add(student);

        System.out.println("Студент успешно добавлен");
    }

    public static void addTeacher() {

        System.out.println("\nДобавление преподавателя");

        System.out.print("ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Фамилия: ");
        String lastName = scanner.nextLine();

        System.out.print("Имя: ");
        String firstName = scanner.nextLine();

        Teacher teacher = new Teacher(
                id,
                lastName,
                firstName,
                "Петрович",
                LocalDate.of(1985, 5, 10),
                "М",
                "+78888888888",
                "teacher@mail.ru",
                id,
                "Java разработка",
                10,
                120000
        );

        teachers.add(teacher);

        System.out.println("Преподаватель успешно добавлен");
    }

    public static void addProgram() {

        System.out.println("\nДобавление программы");

        System.out.print("ID программы: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Название программы: ");
        String name = scanner.nextLine();

        Program program = new Program(
                id,
                name,
                6,
                "Программа обучения"
        );

        programs.add(program);

        System.out.println("Программа успешно добавлена");
    }

    public static void showAllStudents() {

        System.out.println("\n===== СПИСОК СТУДЕНТОВ =====");

        for (Student student : students) {
            System.out.println(student);
        }
    }

    public static void showAllTeachers() {

        System.out.println("\n===== СПИСОК ПРЕПОДАВАТЕЛЕЙ =====");

        for (Teacher teacher : teachers) {
            System.out.println(teacher);
        }
    }
}